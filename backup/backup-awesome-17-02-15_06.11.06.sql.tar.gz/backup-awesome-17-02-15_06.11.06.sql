-- MySQL dump 10.13  Distrib 5.5.54, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: awesome
-- ------------------------------------------------------
-- Server version	5.5.54-0ubuntu0.14.04.1
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('001484927878579095605c09cae46e68adf004e60ea1803000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','九阳神功','呼翕九阳，抱一含元。','气沉于渊力凝山根，故示以虚以无胜有，运气之时，须得气运自我运，不必理外力从何方而……虚实须分清，一处有一处，处处总此虚实……气须鼓荡神宜内敛，无使有缺陷处，无使有凹凸处，无使有断续处，要用意不用劲，随人所动，随屈就伸，挨何处心要用在何处，我劲接彼劲，曲中求直，借力打人，须用四两拨千斤之法……前后左右全无定向，后发制人先发者制于人……彼之力方碍我之皮毛，我之意已入彼之骨里，两手支撑一气贯通，左重则左虚，而右已去，右重则右虚，而左已去……气如车轮周身俱要，相随有不相随处，身便散乱，其病于腰腿求之……先以心使身，从人不从己，从身能从心，由己仍从人，由己则滞，从人则活，能从人，手上便有方寸，秤彼劲之大小，分厘不错，权彼来之长短，毫发无差，前进后退处处恰合，工弥久而技弥精……彼不动，己不动，彼微动，己已动，劲似宽而非松，将展未展，劲断意不断……力从人借，气从脊发，胡能气由脊发？气向下沉，由两肩收入脊骨，布于两膊，施于手指，此气之由下而上也，谓之开，合便是收，开便是放，能得开合，便如阴阳……他强由他强，清风拂山冈，他横任他横，明月照大江，他自狠来他自恶，我自一口真气足。',1484927878.57959);
INSERT INTO `blogs` VALUES ('00148492802381253c39ee2c220456cbf00e68840da1486000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','太极拳','长拳者，如长江大海滔滔不绝也。','太极者，无极而生，阴阳之母也。动之则分，静之则合。无过不及，随曲就伸。人刚我柔谓之走，我顺人背谓之粘。动急则急应，动缓则缓随。虽变化万端，而理惟一贯。由招熟而渐悟懂劲，由懂劲而阶及神明。然非用力日久，不能豁然贯通焉！\n虚灵顶劲，气沉丹田。不偏不倚，忽隐忽现。左重则左虚，右重则右杳。仰之则弥高，俯之则弥深，进之则愈长，退之则愈促。一羽不能加，蝇虫不能落。人不知我，我独知人。英雄所向无敌，盖皆由此而及也。\n斯技旁门甚多，虽势有区别，概不外乎壮欺弱，慢让快耳。有力打无力，手慢让手快，是皆先天自然之能，非关学力而有为也。察四两拨千斤之句，显非力胜，观耄耋能御众之形，快何能为？\n长拳者，如长江大海滔滔不绝也。掤、捋、挤、按、采、挒、肘、靠，此八卦 也。进步、退步、左顾、右盼、中定，此五行也，『掤捋挤按』，即乾坤坎离 四正方也。『采挒肘靠』，即巽震兑艮四斜角也。『进退顾盼定』，即金木水 火土也。合之言之，曰『十三势』。',1484928023.81293);
INSERT INTO `blogs` VALUES ('001484928133531337146a09e314e91a42a8e2553653530000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','九阴真经','天之道损有余而补不足，是故虚胜实，不足胜有余。','天下莫柔弱於水。而攻坚强者，莫之能胜。以其无以易之。弱之胜强。柔之胜刚。天下莫不知莫能行。是以圣人云，受国之垢是谓社稷主。受国不祥是为天下王。正言若反。\n天下之至柔，驰骋天下之至坚。无有入无间，吾是以知无为之有益。不言之教，无为之益天下希及之。\n“人徒之枯坐息，思为进德之功，殊不知上达之士，圆通定慧，体用双修，即动而静，虽撄而宁。”',1484928133.53166);
INSERT INTO `blogs` VALUES ('001484928648633137fe24c0535448ba7fb497c9dd8d03c000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','乾坤大挪移','苦修五百日方可修炼行功，苦修千日则为上乘。','乾坤心法共分七层，第一层【龙象成就】、第二层【十诀剑气】、第三层【逍遥乾坤】，包含【日功】和【月功】；第四层【吸劲神魔】、第五层【横空挪移】、第六层【乾坤归一】，包括第一重【龙爪神功】、第二重【吸星大法】、第三重【天地九阳】；第七层【无极心法】！',1484928648.63321);
INSERT INTO `blogs` VALUES ('001484928718429f0ade4b041224d7c8733628c13919f5c000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','葵花宝典','欲练此功，必先自宫。','欲练神功，引刀自宫。若不自宫，功起热生。热从身起，身燃而生。欲火燃起，自爆而亡。方圆千里，灰飞烟灭。神功大成，一旦自爆，星球破碎，结丹期以下，又或宇宙级之下，必难幸免。由下窜上，燥乱不定。即便热止，身伤不止。自宫以后，真气自生。汇入丹田，无有制碍。气生之法，思色是苦。厌苦舍离，以达性静。性静以后，手若拈花。气绕任脉诸穴，方汇丹田。气成之后，人若新生，妙及无比。再配性淡之食草。如木耳、草菇、冬瓜、薯类等，练药而食。此功一成，出手如雷。招式何用？随手一招，敌不及防，即是杀招。',1484928718.42907);
INSERT INTO `blogs` VALUES ('00148492902202044837f446e474cebb0422497793dfb23000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','降龙十八掌','兵强则灭，木强则折。坚强处下，柔弱处上，有余不尽。','1) 亢龙有悔.\n2) 飞龙在天.\n3) 见龙在田.\n4) 鸿渐于陆.\n5) 潜龙勿用.\n6) 利涉大川.\n7) 突如其来.\n8) 震惊百里.\n9) 或跃在渊.\n10) 双龙取水.\n11) 鱼跃于渊.\n12) 时乘六龙.\n13) 密云不雨.\n14) 损则有孚.\n15) 龙战于野.\n16) 履霜冰至.\n17) 羝羊触蕃\n18) 神龙摆尾.',1484929022.02025);
INSERT INTO `blogs` VALUES ('001484929193600a3d336c9f728437c853a91b6384cf0d1000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','六脉神剑','愿天下有情人终成兄妹。','左手大拇指—手太阴肺经—少商剑。特点：剑路雄劲，颇有石破天惊，风雨大至之势。\n右手食指—手阳明大肠经—商阳剑。特点：巧妙灵活，难以捉摸。\n右手中指—手厥阴心包经—中冲剑。特点：大开大阖，气势雄迈。\n右手无名指—手少阳三焦经—关冲剑。特点：以拙滞古朴取胜。\n右手小指—手少阴心经—少冲剑。特点：轻灵迅速。\n左手小指—手太阳小肠经—少泽剑。特点：忽来忽去，变化精微',1484929193.60019);
INSERT INTO `blogs` VALUES ('001484929398437e544b90ad58c4b649e06ba4bdce312d4000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','凌波微步','体迅飞凫，飘忽若神，凌波微步，罗袜生尘。动无常则，若危若安。','走一步，吸一口气，走第二步时将气呼出，六十四卦走完，四肢全无麻痹之感，料想呼吸顺畅，便无害处。第二次再走时，连走两步吸一口气，再走两步始行呼出。这「凌波微步」是以动功修习内功，脚步踏遍六十四卦一个周天，内息自然而然地也转了一个周天。因此每走一遍，内力便有一分进益。',1484929398.4376);
INSERT INTO `blogs` VALUES ('001484929606601095f3ee64bcd44f6bce19e6042b1ca13000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','玉女剑法','男女与共，当真是说不尽的风流旖旎。','这路剑法每一招中均含着一件韵事，或「抚琴按萧」、或「扫雪烹茶」、或「松下对弈」、或「池边调鹤」。使这套剑法的男女二人倘若不是情侣，则许多精妙之处实在难以体会；假如两人相互间心灵不能沟通，则联剑之际是朋友则太过客气，是尊长小辈则不免照拂仰赖；如属夫妻同使虽妙则妙矣，可是其中的脉脉含情、盈盈娇羞、若即若离、患得患失诸般心情却又差了一层。此时杨过与小龙女相互眷恋极深，然而未结丝萝；内心隐隐又感到前途困厄正多，当真是亦喜亦忧、亦苦亦甜。',1484929606.60164);
INSERT INTO `blogs` VALUES ('001484929791106b14525d2926740348aebb71d25783cad000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','独孤九剑','以无招胜有招，杀尽仇寇奸人，败尽英雄豪杰，打遍天下无敌手。','归妹趋无妄，无妄趋同人，同人趋大有。甲转丙，丙转庚，庚转癸。子丑之交，辰巳之交，午未之交。风雷是一变，山泽是一变，水火是一变。乾坤相激，震兑相激，离巽相激。三增而成五，五增而成九。',1484929791.10686);
INSERT INTO `blogs` VALUES ('001487006483277a932d4a9feed4377b61ee20c418fcea4000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','2017启程','新年过后便是奋斗之时','这个世界最可怕的是比你聪明的人比你更努力',1487006483.27737);
INSERT INTO `blogs` VALUES ('001487126581143eb05476c21ce4b3583dbc8aadd9af00a000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','本站架构','how it comes','##This is a python project for webapp.##\n\n**感谢廖大的教程。**\n\n###准备工作：###\n- python3.5 及以上版本\n- aiohttp: 异步http服务器\n- jinja2: python的模板渲染引擎\n- aiomysql: 异步mysql库\n\n###代码结构：###\nwww  \n+-&nbsp;static:存放静态资源  \n+-&nbsp;templates:存放模板文件  \n&nbsp; -&nbsp;app.py: HTTP服务器以及处理HTTP请求；拦截器、jinja2模板、URL处理函数注册等  \n&nbsp; -&nbsp;orm.py: ORM框架  \n&nbsp; -&nbsp;coroweb.py: 封装aiohttp，即写个装饰器更好的从Request对象获取参数和返回Response对象  \n&nbsp; -&nbsp;apis.py: 定义几个错误异常类和Page类用于分页  \n&nbsp; -&nbsp;config\\_default.py:默认的配置文件信息  \n&nbsp; -&nbsp;config\\_override.py:自定义的配置文件信息  \n&nbsp; -&nbsp;config.py:默认和自定义配置文件合并  \n&nbsp; -&nbsp;markdown2.py:支持markdown显示的插件  \n&nbsp; -&nbsp;pymonnitor.py: 用于支持自动检测代码改动重启服务  \n\n*其中重要的模块有三个：orm.py、coroweb.py、app.py，下面将分别介绍。*\n\n#### orm.py实现思路： ####\nORM全称为对象关系映射(Object Relation Mapping)，即用一个类来对应数据库中的一个表，一个对象来对应数据库中的一行，表现在代码中，即用类属性来对应一个表，用实例属性来对应数据库中的一行。\n\n具体步骤如下：\n\n1. 实现元类ModelMetaclass：创建一些特殊的类属性，用来完成类属性和表的映射关系，并定义一些默认的SQL语句\n2. 实现Model类：包含基本的get,set方法用于获取和设置实例属性的值，并实现相应的SQL处理函数\n3. 实现三个映射数据库表的类：User、Blog、Comment，在应用层用户只要使用这三个类即可\n\n####web框架实现思路：####\n\nweb框架在此处主要用于对aiohttp库做更高层次的封装，从简单的WSGI接口到一个复杂的web framework，本质上还是对request请求对象和response响应对象的处理，可以将这个过程想象成工厂中的一条流水线生产产品，request对象就是流水线的原料，这个原料在经过一系列的加工后，生成一个response对象返回给浏览器。\n\n过程如下：\n\n- app.py中注册所有处理函数、初始化jinja2、添加静态文件路径\n- 创建服务器监听线程\n- 监听线程收到一个request请求\n- 经过拦截器(middlewares)的处理\n- 调用RequestHandler实例中的call方法；再调用call方法中的post或者get方法\n- 调用响应的URL处理函数，并返回结果\n- response_factory在拿到经URL处理函数返回过来的对象，经过一系列类型判断后，构造出正确web.Response对象，返回给客户端',1487126581.14347);

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` VALUES ('001487006490253999fe3d397244e0e9ea80a956cef9061000','001487006483277a932d4a9feed4377b61ee20c418fcea4000','0014845505926227669332c682644178b2065072eb4d7ab000','admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120','感谢廖大。',1487006490.25323);
INSERT INTO `comments` VALUES ('001487138097794079bac8fa22a4065a7c856e7dbe3620b000','001487126581143eb05476c21ce4b3583dbc8aadd9af00a000','001487138072696ab56bb53da644d0d9ce66335d8b384d1000','风清扬','http://www.gravatar.com/avatar/d198088b1f9bb798c8344e6ebc689509?d=mm&s=120','感谢指导！',1487138097.79452);
INSERT INTO `comments` VALUES ('00148713812357045b423caf92f4a45ba293ceb6c39070d000','001484929791106b14525d2926740348aebb71d25783cad000','001487138072696ab56bb53da644d0d9ce66335d8b384d1000','风清扬','http://www.gravatar.com/avatar/d198088b1f9bb798c8344e6ebc689509?d=mm&s=120','无招胜有招',1487138123.57077);

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('0014845505926227669332c682644178b2065072eb4d7ab000','admin@qq.com','2c3d282bc80effe80260bf6f82a845793294d187',1,'admin','http://www.gravatar.com/avatar/34be3c7c0655313619d9b91a7e6f1ee6?d=mm&s=120',1484550592.62391);
INSERT INTO `users` VALUES ('001487138072696ab56bb53da644d0d9ce66335d8b384d1000','fqy@qq.com','76d84514aa2a6934b3180524138473e7f0d33a83',0,'风清扬','http://www.gravatar.com/avatar/d198088b1f9bb798c8344e6ebc689509?d=mm&s=120',1487138072.69698);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-15  6:11:22
